function [ output_args ] = load_channel( input_args )
%LOAD_CHANNEL Summary of this function goes here
%   Detailed explanation goes here


end

