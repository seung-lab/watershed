g++ main.cpp -I. -O3 -DNDEBUG -std=c++11 -o ./bin/ws
